class Main {
	public static void main(String[] a){
		int[] b;
		System.out.println(b); //TE
	}
}

